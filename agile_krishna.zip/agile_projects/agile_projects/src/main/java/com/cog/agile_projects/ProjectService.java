/**
 * 
 */
package com.cog.agile_projects;
import java.util.*;
//import com.cog.agile_projects.Projects;
/**
 * @author Sai Krishna Dalai
 *
 */
public interface ProjectService {
	public Projects addProjects(Projects project);
	public Projects updateProjectDetails(Projects project);
	public  List<Projects> getProjectsList();
	
}
