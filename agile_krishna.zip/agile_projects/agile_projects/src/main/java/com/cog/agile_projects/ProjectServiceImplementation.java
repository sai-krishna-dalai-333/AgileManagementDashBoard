/**
 * 
 */
package com.cog.agile_projects;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



/**
 * @author Sai Krishna Dalai
 *
 */
@Service
public class ProjectServiceImplementation implements ProjectService {
	
	@Autowired
	private ProjectRepo repo;
	
	
	@Override
	public Projects addProjects(Projects project)
	{
		return repo.save(project);
	}
	
	@Override
	public Projects updateProjectDetails(Projects project)
	{
		Projects exist_project =repo.findById(project.getProjectId()).get();
		exist_project.setTitle(project.getTitle());
		exist_project.setBudget(project.getBudget());
		exist_project.setStartDate(project.getStartDate());
		exist_project.setExpectedEndDate(project.getExpectedEndDate());
		exist_project.setCreatedOn(project.getCreatedOn());
		exist_project.setStatus(project.getStatus());
		exist_project.setLastUpdateOn(project.getLastUpdateOn());
		//exist_project.setBookingId(project.getBookingId());
		exist_project.setClientId(project.getClientId());
		
		
		return repo.save(exist_project);
	}
	
	@Override
	public List<Projects> getProjectsList()
	{
		List<Projects> li = repo.findAll();
		return li;
	}
	
	public Projects createProject(Projects project) {
        int numDevelopers = 0;
        int numTesters = 0;
        for (Resources resource : project.getResource()) {
            if (resource.getRole().equals("developer")) {
                numDevelopers++;
            } else if (resource.getRole().equals("tester")) {
                numTesters++;
            }
        }
        if (numDevelopers > 50) {
            throw new MaximumResourceLimitReachedException("Maximum of 50 developers allowed per project");
        }
        if (numTesters > 10) {
            throw new MaximumResourceLimitReachedException("Maximum of 10 testers allowed per project");
        }
        
       return repo.save(project);
	}
	
	public class MaximumResourceLimitReachedException extends RuntimeException {
	    public MaximumResourceLimitReachedException(String message) {
	        super(message);
	    }    
	    
	}
	

}
