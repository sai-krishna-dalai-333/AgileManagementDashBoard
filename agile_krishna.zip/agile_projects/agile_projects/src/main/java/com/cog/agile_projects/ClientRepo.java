/**
 * 
 */
package com.cog.agile_projects;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Sai Krishna Dalai
 *
 */
public interface ClientRepo extends JpaRepository<Clients,Integer> {

}
