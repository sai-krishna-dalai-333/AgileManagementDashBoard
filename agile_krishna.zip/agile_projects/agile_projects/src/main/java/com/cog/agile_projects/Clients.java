package com.cog.agile_projects;
//import com.cog.agile_projects.Projects;
import javax.persistence.*;
//import javax.validation.constraints.*;
import java.util.*;
@Entity
public class Clients {
	    @Id
	    @Column(name="id")
		private int id;
	    @Column(length=50)
		private String name;
		private int fullname;
		@Column(length=16)
		private String phoneNumber;
		@Column(length=100)
		private String email;
		
		
		
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getFullname() {
			return fullname;
		}

		public void setFullname(int fullname) {
			this.fullname = fullname;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
	    private List<Projects> projects = new ArrayList<>();
		
		
		
		public List<Projects> getProjects() {
			return projects;
		}

		public void setProjects(List<Projects> projects) {
			this.projects = projects;
		}

		public Clients(int id, String name, int fullname, String phoneNumber, String email) {
			super();
			this.id = id;
			this.name = name;
			this.fullname = fullname;
			this.phoneNumber = phoneNumber;
			this.email = email;
		}
		
		

}
