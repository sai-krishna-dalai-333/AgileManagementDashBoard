package com.cog.agile_projects;
//import java.time.LocalDate;
import java.util.Date;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgileProjectsApplication implements CommandLineRunner {
	
	@Autowired
	private ResourceService ser;
	
	@Autowired 
	private ProjectService pro_ser;

	public static void main(String[] args) {
		SpringApplication.run(AgileProjectsApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		Resources r = new Resources("12345","sai","krishna","2263041@cognizant.com","9110713691","Developer",15);
		Resources r2 = new Resources("54321","dalai","kris","2263042@cognizant.com","7036944497","Developer",19);
		ser.addResource(r);
		ser.addResource(r2);
		Date d1 = new Date();
		Date d2 = new Date();
		Date d3 = new Date();
		Date d4 = new Date();
		Projects p1 = new Projects(1,"agile",2,d1,d2,d3,"Completed",d4,17);
		
		Date d12 = new Date();
		Date d22 = new Date();
		Date d32 = new Date();
		Date d42 = new Date();
		Projects p2 = new Projects(2,"agile",2,d12,d22,d32,"Completed",d42,17);
		
		Date d13 = new Date();
		Date d23 = new Date();
		Date d33 = new Date();
		Date d43 = new Date();
		Projects p3 = new Projects(3,"agile",2,d13,d23,d33,"Completed",d43,17);
		
		pro_ser.addProjects(p1);
		pro_ser.addProjects(p2);
		pro_ser.addProjects(p3);
		
		List<Projects> li = pro_ser.getProjectsList();
		System.out.println("The list of projects are .......................");
		for(Projects i: li)
		{
			System.out.println("-----------------------------------------");
			System.out.println(i.getProjectId());
			System.out.println(i.getTitle());
			System.out.println(i.getStatus());
			System.out.println(i.getBudget());
			System.out.println(i.getCreatedOn());
			System.out.println(i.getStartDate());
			System.out.println(i.getExpectedEndDate());
			System.out.println(i.getLastUpdateOn());
			
			System.out.println("-----------------------------------------");
			
		}
	}

}
