/**
 * 
 */
package com.cog.agile_projects;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Sai Krishna Dalai
 *
 */
@RestController
@RequestMapping("/api/projects")
public class Controller {

    @Autowired
    private ProjectServiceImplementation projectService;

    @PostMapping("/proj")
    public Projects addProject(@RequestBody Projects project) {
        return projectService.addProjects(project);
    }
    
    @GetMapping("/hello")
    public String crStr()
    {
    	return "Hello World";
    }
    
    @PutMapping("/{projectId}")
    public Projects updateProject(@PathVariable int projectId, @RequestBody Projects project) {
        project.setProjectId(projectId);
        return projectService.updateProjectDetails(project);
    }

    @GetMapping("/pro")
    public List<Projects> getProjects() {
        return projectService.getProjectsList();
    }

    @PostMapping("/create")
    public Projects createProject(@RequestBody Projects project) {
        return projectService.createProject(project);
    }
}

