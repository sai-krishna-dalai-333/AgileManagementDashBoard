package com.cog.agile_projects;
import javax.persistence.*;
import javax.validation.constraints.*;
@Entity
public class Resources {
	
	@Id
	@Column(length=6)
	private String userId;
	
	@Column(length=15)
	@Size(min = 3, message = "First name must be at least 3 characters long")
	private String firstName;
	
	@Size(min = 3, message = "Last name must be at least 3 characters long")
	@Column(length=15)
	private String lastName;
	
	@Column(length=50)
	private String email;
	
	@Column(length=10)
	private String phoneNumber;
	
	@Column(length = 20, columnDefinition = "ENUM('Developer', 'Tester')")  //constraint hat assign values to role attribute
	private String role;
	
	@Column(name="project_code")
	private int project_code;
	
	
	/*

	 * According to the given  ER diagram  there is a many to one relation between the Projects entity and the Relation entity
	 * So to join that there is a primary key projectId for projects entity and foriegn key "ProjectCode" in resources table
	 *join the tables using those keys
	 *
	 *and make many to one relation
	 */	
	
	/*@JoinColumn(name="project_code",referencedColumnName="project_id")
	@ManyToOne(cascade=CascadeType.ALL)
	private Projects project;*/
	
	@ManyToOne
    @JoinColumn(name = "project_id")
    private Projects project;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getProjectCode() {
		return project_code;
	}

	public void setProjectCode(int projectCode) {
		this.project_code = projectCode;
	}

	
	
	/**
	 * @param userId
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param phoneNumber
	 * @param role
	 * @param projectCode
	 */
	public Resources(String userId, String firstName, String lastName, String email, String phoneNumber, String role,int projectCode) 
	{
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.role = role;
		this.project_code = projectCode;
	}
	
    public Resources()
    {
    	
    }
}
