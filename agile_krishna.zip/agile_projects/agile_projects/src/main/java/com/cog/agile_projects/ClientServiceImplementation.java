/**
 * 
 */
package com.cog.agile_projects;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 * @author Sai Krishna Dalai
 *
 */
@Service
public class ClientServiceImplementation implements ClientService {
	@Autowired
	private ClientRepo repo;
	
	@Override
	public List<Clients> getClientsList()
	{
		List<Clients> li = repo.findAll();
		return li;
	}

}
