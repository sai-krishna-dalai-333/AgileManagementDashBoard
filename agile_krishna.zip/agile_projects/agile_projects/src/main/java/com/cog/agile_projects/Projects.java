/* This is the  Projects class which is used to create table in database in mysql . In mysql it wii create the projects table by using the 
 * given variables as attributes  */

package com.cog.agile_projects;
import java.util.Date;

import javax.validation.constraints.*;    // it is used for the constraints
// this package is used to create a entity for an instance
import javax.persistence.*;

import java.util.*;
@Entity
public class Projects {
	@Id
	@Column(name="project_id")
	private int project_id;   // it is the primary  key in the table
	
	@Column(length=50)   // attribute with 50 characters. (varchar(50))
	@Size(min = 3, message = "Title must be at least 3 characters long")  // it is the constraint that titilr should be minimum of length 3 characters
	private String title;
	
	private int budget;
	
	@PastOrPresent
	@Temporal(TemporalType.DATE)
	private Date StartDate;
	
	@Future(message =" Expected date must be future ")
	@Temporal(TemporalType.DATE)
	private Date ExpectedEndDate;
	
	@PastOrPresent
	@Temporal(TemporalType.DATE)
	private Date CreatedOn;
	
	//@Column(length=20)
	@Column(length = 20, columnDefinition = "ENUM('New', 'InProgress', 'Completed', 'Delayed', 'Cancelled')")  // this is the constraint that status must be with those values only
	private String Status;
	
	@PastOrPresent
	@Temporal(TemporalType.DATE)
	private Date LastUpdateOn;
	@Column(name="client_id")
	private int client_id;
	
	
	//It is a method for a contsraint that start date must be less than the expected date.
	@AssertTrue(message = "Expected end date must be greater than start date")
    public boolean isEndDateGreaterThanStartDate() {
        return ExpectedEndDate.compareTo(StartDate) > 0;
    }
	
/*

 * According to the given  ER diagram  there is a many to one relation between the Client entity and the Projects entity
 * So to join that there is a primary key Id for client entity and foriegn key "ClientId" in project table
 *join the tables using those keys
 *
 *and make many to one raltion
 */	
	
	/*@JoinColumn(name="project_id",referencedColumnName="project_code")
	@ManyToOne(cascade=CascadeType.ALL)*/
	
	@ManyToOne
    @JoinColumn(name = "id")
    private Clients client;
	
	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
	private List<Resources> resource;
	
	
	
	public List<Resources> getResource() {
		return resource;
	}


	public void setResouce(List<Resources> resource) {
		this.resource = resource;
	}


	public int getProjectId() {
		return project_id;
	}


	public void setProjectId(int projectId) {
		project_id = projectId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public int getBudget() {
		return budget;
	}


	public void setBudget(int budget) {
		this.budget = budget;
	}


	public Date getStartDate() {
		return StartDate;
	}


	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}


	public Date getExpectedEndDate() {
		return ExpectedEndDate;
	}


	public void setExpectedEndDate(Date expectedEndDate) {
		ExpectedEndDate = expectedEndDate;
	}


	public Date getCreatedOn() {
		return CreatedOn;
	}


	public void setCreatedOn(Date createdOn) {
		CreatedOn = createdOn;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	public Date getLastUpdateOn() {
		return LastUpdateOn;
	}


	public void setLastUpdateOn(Date lastUpdateOn) {
		LastUpdateOn = lastUpdateOn;
	}


	public int getClientId() {
		return client_id;
	}


	public void setClientId(int clientId) {
		client_id = clientId;
	}


	
	
	
	public Projects(int projectId, String title, int budget, Date startDate, Date expectedEndDate, Date createdOn,String status, Date lastUpdateOn, int clientId) 
	{
		super();
		project_id = projectId;
		this.title = title;
		this.budget = budget;
		StartDate = startDate;
		ExpectedEndDate = expectedEndDate;
		CreatedOn = createdOn;
		Status = status;
		LastUpdateOn = lastUpdateOn;
		client_id = clientId;
	}
	 
	
	public Projects()
	{
		
	}
	
		
	

}
