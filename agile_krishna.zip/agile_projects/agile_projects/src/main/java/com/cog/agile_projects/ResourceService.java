/**
 * 
 */
package com.cog.agile_projects;

/**
 * @author Sai Krishna Dalai
 *
 */
public interface ResourceService {
	public Resources addResource(Resources resource);

}
