/**
 * 
 */
package com.cog.agile_projects;
import java.util.*;
/**
 * @author Sai Krishna Dalai
 *
 */
public interface ClientService {
	public List<Clients> getClientsList();

}
