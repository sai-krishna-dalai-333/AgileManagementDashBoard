/**
 * 
 */
package com.cog.agile_projects;

/**
 * @author Sai Krishna Dalai
 *
 */
public class Validations {
	
	//method to validate phone number which is a attribute in resources entity. The phone number must consists of only 10 digits in it
	public void validatePhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Phone number should be exactly 10 digits long");
        }
	}
        
     //method which validates the email address, the email address must end with @cognizant.com other wise throws an exception
	public void validateEmailAddress(String email) {
        if (email == null || !email.endsWith("@cognizant.com")) {
            throw new IllegalArgumentException("Email address should end with '@cognizant.com'");
        }
    }
	
	//method which validates the first name and the last name , in which both the first and last name must be size of 3 charcters or greater than 3.
	
	public void validateFirstName(String firstName) {
        if (firstName == null || !firstName.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("First name should only have alphabets");
        }
    }
    
    public void validateLastName(String lastName) {
        if (lastName == null || lastName.length() < 3 || !lastName.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("Last name should only have alphabets and be at least 3 characters long");
        }
    }
	
      
}
