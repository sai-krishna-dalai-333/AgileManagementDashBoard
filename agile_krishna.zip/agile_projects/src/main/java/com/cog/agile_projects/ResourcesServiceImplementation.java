/**
 * 
 */
package com.cog.agile_projects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Sai Krishna Dalai
 *
 */
@Service
public class ResourcesServiceImplementation implements ResourceService{
     
	@Autowired
	private ResourceRepo repo;
	
	@Override
	public Resources addResource(Resources res)
	{
		return repo.save(res);
	}
}
