package com.cog.agile_projects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgileProjectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgileProjectsApplication.class, args);
	}

}
